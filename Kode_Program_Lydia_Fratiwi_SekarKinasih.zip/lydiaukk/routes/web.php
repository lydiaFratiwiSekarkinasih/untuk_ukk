<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\WebController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\FotoController;
use App\Http\Controllers\LikeController;
use App\Models\foto;
use App\Models\like;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('Home');
});

Route::get('login',[WebController::class,'login']);
Route::post('login',[WebController::class,'AksiLogin']);
Route::get('register',[RegisterController::class,'register']);
Route::post('register',[RegisterController::class,'Aksi']);
Route::post('Logout',[RegisterController::class,'Logout']);
Route::get('/koleksi', [WebController::class,'koleksi']);
Route::post('/koleksi', [WebController::class,'BuatAlbum']);

Route::post('/unggah', [WebController::class,'unggah']);

Route::get('halut', function (){
    $foto = foto::all();
    $like = like::all();
    return view('Halut', compact('foto','like'));
});


Route::get('/album', function () {
    return view('album ');
});

Route::get('/isifoto', function () {
    return view('isifoto');
});

Route::get('/isifoto/{AlbumID}', [WebController::class,'isifoto']);

Route::get('/unggah', [FotoController::class,'foto']);
Route::post('/isifoto', [FotoController::class,'tambahFoto']);


Route::get('/homwal', function () {
    return view('Homwal');
});

Route::get('/datafoto{AlbumID}', [LikeController::class, 'datafoto']);
                                                                
Route::get('/liatfoto/{FotoID}', [LikeController::class, 'tampilkomentar']);
Route::get('/berilike/{FotoID}', [LikeController  ::class, 'like']);
Route::post('/Halut/{FotoID}', [LikeController::class, 'AksiTambahKomentar']);
Route::get('/komen/{FotoID}', [LikeController  ::class, 'Tampilkomentar']);