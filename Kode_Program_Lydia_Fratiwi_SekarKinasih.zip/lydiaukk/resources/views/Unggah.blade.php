<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Unggah Album</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            background-color: #ffbbbb;
        }

        .navbar{
            margin-bottom: 500px;
        }

        .container {
            background-color: #transparant;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 30px;
        }

        h2 {
            color: #333;
        }

        form {
            max-width: 600px;
            margin: auto;
        }

        label {
            color: #555;
        }

        textarea {
            resize: vertical;
        }
    </style>
</head>

<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">{{(Session()->get('user')->Username)}}</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href=""></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="halut">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="koleksi ">Koleksi</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="album ">Album</a>
          </li>
        </ul>
        </form>
      </div>
    </div>
  </nav>
</header>
<body>

<div class="container mt-5">
    <h2 class="mb-4">Unggah Foto</h2>
    <form action="/isifoto" method="post" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label for="albumName" class="form-label">Judul Foto</label>
            <input type="text" class="form-control" id="albumName" name="JudulFoto" required>
        </div>
        <div class="mb-3">
            <label for="albumDescription" class="form-label">Deskripsi Foto</label>
            <textarea class="form-control" id="albumDescription" name="DeskripsiFoto" rows="3"></textarea>
        </div>
        <div class="mb-3">
            <label for="albumCover" class="form-label">Pilih Foto</label>
            <input type="file" class="form-control"name="foto" accept="image/*" required>
        </div>

        <select name="album" class="form-control my-4 py-2 custom-input">
          <option>Pilih Album</option>
          @foreach($album as $item)
              <option value="{{ $item->AlbumID}}">{{ $item->NamaAlbum }}</option>
              @endforeach
      </select>

        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

</body>
</html>
