<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Home</title>
    </head>
<body>
    <style>
body {
            font-family: 'Arial', sans-serif;
            background-color: #E6A4B4;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

    </style>
<header>

<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">GALERY FOTO</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          
        </ul>
        
      </div>
    </div>
  </nav>
</header>
<main class="container">
    <div class="p-4 p-md-5 mb-4 text-dark rounded bg-transparent">
        <div class="col-md-7 px-0" style="font-family: 'Times New Roman', Times, serif;">
            <h1 class="display-4  fw-bold">SELAMAT DATANG DIGALERY FOTO</h1>
            <p class="lead my-3">Sebuah ruang virtual yang memukau dimana seni dan keindahan bersatu. Disini,
          kami mengundang Anda untuk memnjelajahi koleksi kami yang kaya akan karya-karya visual yang luar biasa. Setiap gambar dipilih dengan cermat
          untuk menghadirkan pengalaman yang memikat, mengundang anda untuk melihat rekomendasi anime, film, dan foto lainnya. Lalu kalian bisa Membuat album sendiri dan mengupload seperti dibawah ini.</p>
        </div>
    </div>
    <p>
          <!-- <a href="homwal" class="btn btn-primary my-2">Lanjut...</a> -->
          <a href="homwal" class="btn btn-secondary my-2">Next</a> 
        </p>

</main>

    </div>
  </div>
</body>
</html>