<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Foto</title>
</head>

<style>

    body{
        background-color: #936B9D;
    }

    header {
    background-color: #fff8e3;
    color: #fff;
    text-align: center;
    padding: 20px;
}

.overlay {
        background-color: transparant;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        width: 100%;
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
    }

    button {
    background-color: #ffff;
            color: #ff80ff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
  
  
}

.gallery {
    display: flex;
    flex-wrap: wrap;
    justify-content:;
}

.photo {
    backround-color: #C28AD1;
    position: relative;
    margin: 20px;
    overflow: hidden;
    border-radius: 8px;
    box-shadow:  0 4px 8px rgba(0, 0, 0, 0.2);
    transition: transform 0.3s ease-in-out;
    margin-top: 50px;
}

.photo img {
    max-width: 100%;
    height: auto;
    display: block;
}



 .photo:hover {
    transform: scale(1.05);
}

.photo:hover .overlay {
    opacity: 1;
}

.overlay h3 {
    margin-bottom: 1px;
}





</style>

<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">{{(Session()->get('user')->Username)}}</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="/"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="halut">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="unggah ">Unggah</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="album">Album</a>
          </li>
        </ul>
        </form>
      </div>
    </div>
  </nav>
</header>

<body>
 
    @foreach($album as $item)
<section class="gallery">
        <div class="photo">
          
            <img src="jenong.jpeg" alt=""> 
            <div class="overlay">
                <center>
                <h3>{{ $item-> NamaAlbum }}</h3>
                </center>
                <p>{{ $item-> Deskripsi }}</p>
                

              <div class="link">
                <center>
                <button><a href="/isifoto/{{ $item->AlbumID }}" >Lihat Album</button>
                </center>
              </div>
            </div>
        </div>
        @endforeach


        
        
       
    </section>
</body>
</html>