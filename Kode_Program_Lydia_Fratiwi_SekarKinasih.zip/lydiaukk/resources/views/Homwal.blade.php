<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
    <title>halaman Utama Login</title>
    
</head>

<style>
    body{
        background-color:#ffb7b7;
    }


    .swiper-container {
      width: 100%;
      padding: 20px;
      margin-top: 50px;
    }

    /* .swiper-slide {
      background-color: black;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      overflow: hidden;
    } */

    .swiper-slide img {
      width: 100%;
      height: 40%;
      object-fit: cover;
    }

    @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
</style>

<body>

<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">GALERY FOTO</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="/">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="register">Daftar</a>
          </li>
        </ul>
        </form>
      </div>
    </div>
  </nav>
</header>

<div class="swiper-container">
    <div class="swiper-wrapper">
      <div class="swiper-slide"><img src="gib.jpg" alt="Kartu 1"></div>
      
    </div>
     </div>

  <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
  
  

    <div class="container">

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
            <img src="{{ ('howl.jpg') }} "width="100%" height="225">

            <div class="card-body">
              <center>
              <h2> Howl's Moving Castle</h2>
    </center>
              <p class="card-text">"Howl's Moving Castle" adalah film animasi Jepang yang dirilis pada tahun 2004, diproduksi oleh Studio Ghibli dan disutradarai oleh Hayao Miyazaki. Film ini didasarkan pada novel dengan judul yang sama karya Diana Wynne Jones. Cerita ini mengikuti perjalanan seorang gadis muda bernama Sophie yang dikutuk oleh penyihir menjadi seorang wanita tua. Dia bertemu dengan penyihir muda bernama Howl dan memasuki kastil berjalan miliknya yang ajaib. Kalian bisa menonton nya di berbagai situs atau aplikasi tontonan lainnya.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  
                </div>
                
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="{{ ('one.jpg') }} " width="100%" height="225">

            <div class="card-body">
              <center>
              <h2>One Piece</h2>
    </center>
              <p class="card-text">"One Piece" mengikuti petualangan Monkey D. Luffy, seorang anak muda yang memperoleh kekuatan buah setan dan ambisi untuk menjadi Raja Bajak Laut dan menemukan harta legendaris bernama One Piece. Luffy bersama dengan kru bajak lautnya yang beragam, yang dikenal sebagai Kru Topi Jerami, menjelajahi lautan Grand Line untuk mencapai tujuannya. Selama perjalanan mereka, mereka menghadapi berbagai tantangan, bertemu musuh dan sekutu baru, dan mengungkap misteri dunia. tonton animenya diwebsite atau di youtube dan nikmati pertualangannya</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  
                </div>
                
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
          <img src="{{ ('rimuru.jpg') }} " width="100%" height="225">

            <div class="card-body">
            <center>
             <h2>Tensei Shitara Slime Datta Ken</h2>                                                   
    </center>
              <p class="card-text">Seseorang yang awalnya merupakan pria kantor berusia 37 tahun tewas setelah diserang. Namun, setelah kematiannya, dia terlahir kembali dalam dunia fantasi sebagai slime ajaib dengan kemampuan unik. Slime ini memiliki kemampuan untuk memakan dan menyerap segala sesuatu yang ada di sekitarnya, yang memungkinkannya untuk memperoleh keterampilan dan karakteristik berbagai makhluk.Kalian bisa menonton nya di berbagai situs atau aplikasi tontonan lainnya. </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                 
                </div>
                
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img src="{{ ('harry.jpg') }} " width="100%" height="225">

            <div class="card-body">
            <center>
             <h2>Harry Potter</h2>                                                   
    </center>
              <p class="card-text"> "Harry Poter" mengisahkan tentang petualangan seorang penyihir remaja bernama Harry Potter dan sahabatnya, Ron Weasley dan Hermione Granger, yang merupakan pelajar di Sekolah Sihir Hogwarts. Inti cerita dalam novel-novel ini berpusat pada upaya Harry untuk mengalahkan penyihir hitam jahat bernama Lord Voldemort, yang berambisi untuk menjadi makhluk abadi, menaklukkan dunia sihir, menguasai orang-orang nonpenyihir, dan membinasakan siapapun yang menghalangi jalannya, terutama Harry Potter.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  
                </div>
                
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img src="{{ ('partners.jpg') }} "  width="100%" height="225">

            <div class="card-body">
            <center>
             <h2>Partner Of Justice</h2>                                                   
    </center>
              <p class="card-text">Drama ini mengikuti seorang jaksa forensik yang brilian dan ahli patologi forensik yang bekerja sama untuk memecahkan berbagai kasus kriminal. Mereka menggunakan pendekatan ilmiah dan analisis forensik untuk mengungkap kebenaran di balik setiap kasus, sambil menghadapi tantangan dan rintangan di sepanjang jalan. Kelanjutan dari musim pertama, "Partners for Justice 2" melanjutkan kisah para ahli forensik yang bekerja sama untuk menyelesaikan berbagai kasus kriminal yang rumit. kalian bisa menonton drama ini di berbagai situs</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                
                </div>
                
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img src="{{ ('nr.jpg') }} " width="100%" height="225">

            <div class="card-body">
            <center>
             <h2>Narnia I</h2>                                                   
    </center>
              <p class="card-text">"The Lion, the Witch and the Wardrobe" mengisahkan kisah empat saudara - Peter, Susan, Edmund, dan Lucy Pevensie - yang dievakuasi ke properti pedesaan selama Perang Dunia II. Mereka menemukan pintu lemari pakaian yang menghubungkan mereka ke dunia ajaib Narnia. Di Narnia, mereka terlibat dalam konflik besar antara kebaikan dan kejahatan, yang dipimpin oleh penyihir jahat Jadis. Mereka bertemu dengan karakter ajaib, makhluk fantastis, dan, yang paling penting, Aslan, singa ajaib yang mewakili kebaikan dan keadilan.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                 
                </div>
                
              </div>
            </div>
          </div>
        </div>

      
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>

    
  