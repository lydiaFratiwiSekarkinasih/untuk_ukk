<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
    <title>halaman Utama Login</title>
    
</head>

<style>
    body{
        background-color:#ffb7b7;
    }


    .swiper-container {
      width: 100%;
      padding: 20px;
      margin-top: 50px;
    }


    .swiper-slide img {
      width: 100%;
      height: 40%;
      object-fit: cover;
    }

    @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        } 
      }
</style>

<body>

<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">{{(Session()->get('user')->Username)}}</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          
          <li class="nav-item">
            <a class="nav-link" href="/koleksi">Fotomu</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/ ">Logout</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/unggah ">Upload Foto</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="album ">Album</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="album "></a>
          </li>
        </ul>
        </form>
      </div>
    </div>
  </nav>
</header>

<div class="swiper-container">
    <div class="swiper-wrapper">
      <div class="swiper-slide"><img src="gib.jpg" alt="Kartu 1"></div>
      
    </div>
     </div>

  <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
  
  

    <div class="container">

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        @foreach($foto as $item)
        <div class="col">
          <div class="card shadow-sm">
            <img src="{{ asset($item->LokasiFile) }} "width="100%" height="225">

            <div class="card-body">
              <center>
              <h2>{{$item->JudulFoto}}</h2>
              </center>
              <p class="card-text">{{$item->DeskripsiFoto}}</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <center>
                  @if ($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $item->FotoID)->first())
                        <a href="/berilike/{{ $item->FotoID }}">
                            <i class="fa-solid fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        {{ $like->where('FotoID', $item->FotoID)->count() }}
                    @else
                        <a href="/berilike/{{ $item->FotoID }}">
                            <i class="fa-regular fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        {{ $like->where('FotoID', $item->FotoID)->count() }}
                    @endif                  <button type="button" class="btn btn-sm btn-outline-secondary"><a href="/liatfoto/{{$item->FotoID}}">Komentar</button></a>
                  </center>
                </div>
                <small class="text-muted"></small>
              </div>
            </div>
          </div>
        </div>
        @endforeach
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
        <script src="https://kit.fontawesome.com/29c53c391a.js" crossorigin="anonymous"></script>
</body>
</html>