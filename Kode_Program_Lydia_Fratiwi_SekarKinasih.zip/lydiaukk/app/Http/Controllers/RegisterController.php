<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\userr;
use App\Models\Album;

class RegisterController extends Controller
{
    public function register(){
        return view('Register');
    }

    public function aksi(Request $request){
        
        $data = new userr;
        $data->Username = $request->input('Username');
        $data->Password = $request->input('Password');
        $data->Email = $request->input('Email');
        $data->NamaLengkap = $request->input('NamaLengkap');
        $data->Alamat = $request->input('Alamat');
        $data->save();

        return redirect('/login')->with('regsukses', 'registrasi berhasil silahkan login');
    }
}
