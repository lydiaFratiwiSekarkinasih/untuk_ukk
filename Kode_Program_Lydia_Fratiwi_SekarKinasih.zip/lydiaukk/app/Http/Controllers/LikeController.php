<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Userr;
use App\Models\Foto;
use App\Models\Like;
use App\Models\Komentar;
use Carbon\Carbon;

class LikeController extends Controller
{
    public function lihat(){
        $komentar=Komentar::all();
    }
    public function like($FotoID){
        $cek = Like::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first();
        if(!$cek){
            $like = new like;
            $like->FotoID = $FotoID;
            $like->UserID = session('user')->UserID;
            $like->TanggalLike = Carbon::now();
            $like->save();
            
            return redirect()->back();
        }else{
            $cek->delete();

            return redirect()->back();
        }
    }
    public function AksiTambahKomentar($FotoID, Request $req){
        $data = new Komentar;
        $data->FotoID = $FotoID;
        $data->UserID = session('user')->UserID;
        $data->IsiKomentar = $req->input('isi');
        $data->TanggalKomentar = date('y-m-d');
        $data->save();

        return redirect('/liatfoto/' .$FotoID);
    }


    Public function tampilkomentar($FotoID){
        if(session('user')!=null){
            $foto = Foto::find($FotoID);
            $komentar = komentar::where('FotoID', $FotoID)->get();
            return view('komen', compact('foto','komentar', 'FotoID'));
        

        }
    }
}