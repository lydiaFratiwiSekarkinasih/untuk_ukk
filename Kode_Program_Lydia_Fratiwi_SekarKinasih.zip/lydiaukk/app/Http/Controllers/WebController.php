<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\models\userr;
use App\models\Album;
use App\models\Foto;

class WebController extends Controller
{
    public function login()
    {
        return view('login');
    }
    public function AksiLogin(Request $request){
        $data = userr::where('username', $request->input('username'))->where('password', $request->input('password'))->first();
        if ($data != null) {
            session()->put('user', $data);
            return redirect('/halut');
        } else {
            return redirect()->back()->with('pesan', 'Username / Password Salah!!');
        }


        
    }
    public function Logout(){
        session()-> flush();
        return view('Home');
    }

    public function BuatAlbum(Request $request)
    {
        $data = new Album();
        $data -> NamaAlbum = $request->input('NamaAlbum');
        $data -> Deskripsi = $request->input('Deskripsi');
        $data -> TanggalDiBuat = date('Y-m-d');
        $data -> UserID = session('user')->UserID;

        $data -> save();
        //dd($album);

        Session()->flash('success', 'Album Berhasil ditambah!!!');
        return redirect ('/koleksi');
        


    }

    public function unggah(){
        $album = Album::where('UserID',session('user')->UserID)->get();

        return view('unggah',compact ('album'));
    }

    public function isifoto($AlbumID){
        if(session ('user') != null){

        $foto = Foto::where('AlbumID', $AlbumID)->get();
        return view('isifoto', compact('foto'));

       }else{
        return redirect('/login')->with('success', 'Album  berhasil ditambahkan');
       }
    }

    public function koleksi()
    {
        if(session ('user') != null){
        $album = Album::where('UserID', session('user')->UserID)->get();
        return view('koleksi', compact('album'));

       }else{
        return redirect('/login')->with('success', 'Album berhasil ditambahkan');

       }
    }
}
