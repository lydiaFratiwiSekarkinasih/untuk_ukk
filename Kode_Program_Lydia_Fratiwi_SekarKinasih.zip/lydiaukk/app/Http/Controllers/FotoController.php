<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facedes\Auth;
use App\Models\userr;
use App\Models\Album;
use App\Models\Foto;

class FotoController extends Controller
{
    public function foto()
    {
        $album = Album::where('UserID',session('user')->UserID)->get();
        return view('unggah', compact('album'));
    }

    

    public function tambahFoto(Request $request)
    {
        $filefoto = $request->file('foto');
        $filefoto->move('folder',$filefoto->getClientOriginalName());

        $data = new Foto();
        $data -> JudulFoto = $request->input('JudulFoto');
        $data -> DeskripsiFoto = $request->input('DeskripsiFoto');
        $data -> TanggalUnggah = date('Y-m-d');
        $data -> LokasiFile = '/folder/'.$filefoto->getClientOriginalName();
        $data -> UserID = session ('user')->UserID;
        $data -> AlbumID = $request->input('album');
        $data -> save();
        // dd($album);

        Session()->flash('success', 'Foto Berhasil ditambahkan !');
        return redirect ('/koleksi');
    }
}