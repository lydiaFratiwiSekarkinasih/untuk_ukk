<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Halaman Register</title>
</head>
<style>
    body {
            font-family: 'Arial', sans-serif;
            background-color: #E7BCDE; 
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }


.register-container {
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    width: 300px;
    text-align: center;
    margin-top: 50px;
}

h1 {
    color: #ff69b4; 
    background: #ffffff;
    padding: 10px;
    border-radius: 15px;
}

input {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    box-sizing: border-box;
    border: 1px solid #ffb6c1; 
    border-radius: 5px;
}

button {
    background-color: #ff69b4; 
    color: #ffffff;
    padding: 10px 20px;
    border: none;
    border-radius: 25px;
    cursor: pointer;
}

button:hover {
    background-color: #ff1493; 
}
</style>
<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">GALERY FOTO</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="homwal">Kembali</a>
          </li>
          
        </ul>
        
      </div>
    </div>
  </nav>
</header>
<body>
<div class="register-container">
        <h1><strong>Register</strong></h1>
        <form action="/register" method="post">
        <?php echo csrf_field(); ?>
            <input type="text" name="Username" placeholder="Username" required>
            <input type="password" name="Password" placeholder="Password" required>
            <input type="email" name="Email" placeholder="Email" required>
            <input type="text" name="NamaLengkap" placeholder="Nama Lengkap" required>
            <input type="text" name="Alamat" placeholder="Alamat" required>

            <center>
                <div>    
            <p class="reg-info">sudah punya akun?<a href="/login">login disini!</a></p>
            <br>
                  </div>
            </center>
            
            <button type="submit" value="register">Register</button>
        </form>

        
</div>
    
</body>
</html><?php /**PATH C:\laragon\www\lydiaukk\resources\views/Register.blade.php ENDPATH**/ ?>