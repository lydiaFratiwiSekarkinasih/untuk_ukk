<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Foto</title>
</head>

<style>

    body{
        background-color: #CAA6A6;
    }

    header {
    background-color: #fff8e3; /* Warna coklat muda */
    color: #fff;
    text-align: center;
    padding: 20px;
}

 

.gallery {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.photo {
    position: relative;
    margin: 20px;
    overflow: hidden;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease-in-out;
    margin-top:70px;
   
}

.photo img {
    max-width: 100%;
    height: 100%;
    display: block;
}



.photo:hover {
    transform: scale(1.05);
}

.photo:hover .overlay {
    opacity: 1;
}

.overlay {
    max-width:300px; 
    overflow: hidden;
}

.overlay h3 {
    margin-bottom: 1px;
    
    
}




</style>

<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">GALERY FOTO</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="/">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/halut">beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/unggah">Tambah Foto</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/album">Album</a>
          </li>
        </ul>
        </form>
      </div>
    </div>
  </nav>
</header>

<body>
    <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="gallery">
        <div class="photo">
            
            <div class="overlay">
                <img src="<?php echo e($item->LokasiFile); ?>" style="height:200px; width:300px">
                <h3><?php echo e($item-> JudulFoto); ?></h3>
                <p><?php echo e($item-> DeskripsiFoto); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        
       
    </section>
</body>
</html><?php /**PATH C:\laragon\www\lydiaukk\resources\views/isifoto.blade.php ENDPATH**/ ?>