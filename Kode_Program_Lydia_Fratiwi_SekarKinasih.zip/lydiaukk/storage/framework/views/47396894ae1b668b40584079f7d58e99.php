<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        margin : 0;
        padding: 0;
        height: 100vh;
        background-color: #AC7D88;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .card{
        margin-top: 150px;
        width: auto;
        height: auto;
    }


    .navbar {
        margin-bottom: 20px; /* Tambahkan margin di sini sesuai kebutuhan */
       
    }

    .create-kom {
        width: 40%;
        margin-bottom: 30px; /* Tambahkan margin di sini sesuai kebutuhan */
    }
</style>
<header>

<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#"><?php echo e((Session()->get('user')->Username)); ?></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="/halut">kembali</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          
        </ul>
        
      </div>
    </div>
  </nav>
</header>

<body>
    <div class="create-kom">
        <div class="card">
            <img src="<?php echo e(asset($foto->LokasiFile)); ?>" width="35%" height="35%" class="card-img-top" alt="Photo">
            <div class="card-body">
                <form action="/Halut/<?php echo e($FotoID); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <input type="text" name="isi" placeholder="Masukkan komentar kamu..." required class="form-control">
                    </div>
                   
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit</button>
                    
                </form>
                <hr>
                <div>
                    <?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($item->IsiKomentar); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://kit.fontawesome.com/29c53c391a.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-yGbOAzX1DzBoM6hZDyVaMjMg2Uj8BveSz/wn6kc5vqBgceU1E6QggN5t9RSJoDfC" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\lydiaukk\resources\views/komen.blade.php ENDPATH**/ ?>